/// <reference types="vite/client" />
/// <reference types="vue/macros-global" />